<?php
include 'user.php';

$title = "title";
$body = "3";

include 'template.php';

?>
