
<html>
	<head>
		<title><?php echo $title; ?></title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

	</head>
	<body bgcolor="#fdd42f">

		<table cellspacing="0" cellpadding="0" border="0" align="center" width="955" >
			<tbody>
				<tr>
					<td>
					<table cellspacing="0" cellpadding="0" border="0" align="center" width="955" height="116">
						<tbody>
							<tr>
								<td width="270" height="116" colspan="7"><img height="116" src="images/header.png"></td>

							</tr>
						</tbody>
					</table>
					<table cellspacing="0" cellpadding="0" border="0" background="images/bg.png" align="center" width="955" height="30">
						<tbody>
							<tr>
								<td height="30">
								<table cellspacing="0" cellpadding="0" border="0" width="955" style="font-family: Tahoma;
								font-size: 9pt; font-weight: 600">
									<tbody>
										<tr>
											<td width="200" height="26"><a href='/login.php'>
											<?php
											if (is_authorized())
												echo "خروج";
											else
												echo "ورود";
											?>
											</a></td>
											<td align="right" width="200"><a href="/pages/email.html">دانشکده مهندسی کامپیوتر</a><img width="11" height="11" src="images/db.png"></td>
											<td align="right" width="65"><a href="/pages/email.html">افزودن</a><img width="11" height="11" src="images/db.png"></td>
											<td align="right" width="120"><a href="/pages/email.html">ویرایش مطالب</a><img width="11" height="11" src="images/db.png"></td>
											<td align="right" width="53"><a href="/pages/user.html">کاربر</a><img width="11" height="11" src="images/db.png"></td>
											<td align="right" width="104"><a href="/docs/Phase2.pdf">مستند فاز دو</a><img width="11" height="11" src="images/db.png"></td>
											<td align="right" width="110"><a href="/docs/Phase1.pdf">مستند فاز یک</a><img width="11" height="11" src="images/db.png"></td>
											<td align="right" width="120"><a href="/docs/Phase0.pdf">مستند فاز صفر</a><img width="11" height="11" src="images/db.png"></td>
											<td align="right" width="105"><a href=".">صفحه اصلي</a><img width="11" height="11" src="images/db.png"></td>
											<td width="15"></td>
										</tr>
									</tbody>
								</table></td>
							</tr>
						</tbody>
					</table></td>
				</tr>
			</tbody>
		</table>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="955" dir="rtl">
			<tbody>
				<tr>
					<td>
					<table cellspacing="0" cellpadding="0" border="0" align="center" width="100%" height="100%">
						<!--DWLayoutTable-->
						<tbody>
							<tr>
								<td bgcolor="#ffffff" width="760" valign="top" height="2" colspan="3"></td>
							</tr>
							<tr>
								<td bgcolor="#FFFFFF" align="center" width="185" valign="top" height="100%">
								<table cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffff" width="180" height="100%">
									<tbody>
										<tr>
											<td bgcolor="#ffffff" height="5"></td>
										</tr>
										<tr>
											<td bgcolor="#ffffff" height="100%">
											<table cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffcc" width="180" height="100%" dir="rtl">
												<tbody>
													<tr></tr>
													<tr>
														<td width="180" height="18" colspan="2"><img width="180" height="18" alt="" src="images/menu.gif"></td>
													</tr>
													<tr>
														<td align="left" width="14" valign="middle" height="11"><img align="top" width="14" height="11" src="images/db.png"></td>
														<td width="166" height="11" ><a href="" style="TEXT-DECORATION: none">فهرست تمام فیلم‌ها</a></td>

													</tr>
													<tr>
														<td align="left" width="14" valign="middle" height="11"><img align="top" width="14" height="11" src="images/db.png"></td>
														<td width="166" height="11" ><a href="" style="TEXT-DECORATION: none">تمام سینماگرها</a></td>

													</tr>
													<tr>
														<td align="left" width="14" valign="middle" height="11"><img align="top" width="14" height="11" src="images/db.png"></td>
														<td width="166" height="11" ><a href="" style="TEXT-DECORATION:none;">شرکت‌های تهیه‌کننده</a></td>

													</tr>
													<tr>
														<td align="left" width="14" valign="top" height="11"></td>
														<td width="166" height="11" ></td>
													</tr>
													<tr>
														<td width="180" height="18" colspan="2"><img width="180" height="18" alt="" src="images/menu.gif"></td>
													</tr>
													<tr>
														<td width="14" valign="middle" height="11"><img align="top" width="14" height="11" src="images/db.png" ></td>
														<td width="166" height="11" ><a href="" style="TEXT-DECORATION: none">خرید بلیط</a></td>

													</tr>
													<tr>
														<td width="14" valign="middle" height="11"><img align="top" width="14" height="11" src="images/db.png"  ></td>
														<td width="166" height="11"><a href="" style="TEXT-DECORATION: none">جشنواره‌ها </a></td>

													</tr>
													<tr>
														<td width="14" valign="middle" height="11"><img align="top" width="14" height="11" src="images/db.png" ></td>
														<td width="166" height="11" ><a href="" style="TEXT-DECORATION:none;">جوایز</a></td>

													</tr>
													<tr>
														<td width="14" valign="top" height="11"></td>
														<td width="166" height="11" ></td>
													</tr>
													<tr>
														<td width="180" height="18" colspan="2"><img width="180" height="18" alt="" src="images/menu.gif"></td>
													</tr>
													<tr>
														<td width="14" valign="middle" height="11"><img align="top" width="14" height="11" src="images/db.png" ></td>
														<td width="166" height="11"  ><a href="" style="TEXT-DECORATION: none">نظرات</a></td>
													</tr>
													<tr>
														<td width="14" valign="middle" height="11"><img align="top" width="14" height="11" src="images/db.png" ></td>
														<td width="166" height="11" ><a href="" style="TEXT-DECORATION: none">خلاصه
														داستان فيلم</a></td>

													</tr>
													<tr>
														<td width="14" valign="top" height="11"></td>
														<td width="166" height="11" ></td>
													</tr>
													<tr>
														<td width="180" valign="top" height="18" colspan="2"><img width="180" height="18" alt="" src="images/menu.gif"></td>
													</tr>
													<tr>
														<td width="14" valign="middle" height="11" style="WIDTH: 14px"><img align="top" width="14" height="11" src="images/db.png"></td>
														<td width="166" valign="middle" height="11"><a href="" style="TEXT-DECORATION:none;">سرمایه‌گذارها</a></td>

													</tr>
													<tr>
														<td width="14" valign="middle" height="18" style="WIDTH: 14px"><img align="top" width="14" height="11" src="images/db.png"></td>
														<td width="166" valign="middle" height="11"><a href="" style="TEXT-DECORATION:none;">اکران‌ها</a></td>

													</tr>
													<tr>
														<td width="14" valign="middle" height="18" style="WIDTH: 14px"><img align="top" width="14" height="11" src="images/db.png" ></td>
														<td width="166" valign="middle" height="11"><a href="" style="TEXT-DECORATION:none;">فهرست هنرمندان</a></td>

													</tr>
													<tr>
														<td width="14" valign="middle" height="18" style="WIDTH: 14px"><img align="top" width="14" height="11" src="images/db.png"></td>
														<td width="166" valign="middle" height="11"><a href="" style="TEXT-DECORATION:none;">&nbsp;به
														تفکيک جشنواره </a></td>

													</tr>
													<tr>
														<td valign="middle" height="18" style="WIDTH: 14px"><img align="top" width="14" height="11" src="images/db.png" ></td>
														<td width="166" valign="middle" height="11"><a  href="" style="TEXT-DECORATION:none;">&nbsp;به
														تفکيک دفاتر توليد</a></td>

													</tr>
													<tr>
														<td width="14" valign="top" height="11" style="WIDTH: 14px"></td>
														<td width="166" height="11" ></td>
													</tr>
													<tr>
														<td width="180" height="18" colspan="2"><img width="180" height="18" alt="" src="images/menu.gif"></td>
													</tr>
													<tr>
														<td width="14" valign="middle" height="11"><img align="top" width="14" height="11" src="images/db.png"></td>
														<td width="166" height="11"><a href="" style="TEXT-DECORATION: none">آلبوم
														عكس </a></td>

													</tr>
													<tr>
														<td width="14" valign="middle" height="11"><img align="top" width="14" height="11" src="images/db.png" ></td>
														<td width="166" height="11"><a href="" style="TEXT-DECORATION: none">عكس
														های&nbsp;&nbsp;فيلم&nbsp; </a></td>

													</tr>
													<tr>
														<td width="14" valign="middle" height="11"><img align="top" width="14" height="11" src="images/db.png" ></td>
														<td width="166" height="11" ><a  href="" style="TEXT-DECORATION:none;">جوایز نامزد شده</a></td>

													</tr>
													<tr>
														<td width="14" valign="middle" height="11"><img align="top" width="14" height="11" src="images/db.png" ></td>
														<td width="166" height="11"><a  href="" style="TEXT-DECORATION:none;">پوستر فیلم </a></td>

													</tr>
													<tr>
														<td width="14" valign="middle" height="11"><img align="top" width="14" height="11" src="images/db.png" ></td>
														<td width="166" height="11"><a  href="" style="TEXT-DECORATION: none">دیالوگ‌های برگزیده</a></td>

													</tr>
													<tr>
														<td width="14" valign="top" height="11"></td>
														<td width="166" height="11" ></td>
													</tr>
													<tr>
														<td height="18" colspan="2"><img width="180" height="18" alt="" src="images/menu.gif"></td>
													</tr>
													<tr>
														<td width="14" valign="middle" height="11"><img align="top" width="14" height="11" src="images/db.png" ></td>
														<td width="166" height="11"><a href="" style="TEXT-DECORATION:none;">فیلم به تفکیک زبان</a></td>

													</tr>
													<tr>
														<td width="14" valign="middle" height="11"><img align="top" width="14" height="11" src="images/db.png" ></td>
														<td width="166" height="11"><a href="" style="TEXT-DECORATION:none;">کارگردان‌ها</a></td>

													</tr>
													<tr>
														<td width="14" valign="middle" height="11"><img align="top" width="14" height="11" src="images/db.png" ></td>
														<td width="166" height="11"><a href="" style="TEXT-DECORATION:none;">امتیازها</a></td>

													</tr>
													<tr>
														<td width="14" valign="top" height="100%"></td>
														<td width="166" height="100%" ></td>
													</tr>
												</tbody>
											</table></td>
										</tr>
									</tbody>
								</table></td>
								<td bgcolor="#ffffff" width="27" valign="top" height="100%" style="WIDTH: 32px"></td>
								<td bgcolor="#ffffff" width="743" valign="top" height="100%">
								<?php echo $body; ?>
								<p>
									&nbsp;
								</p></td>
							</tr>
						</tbody>
					</table></td>
				</tr>
			</tbody>
		</table>
		<table cellspacing="0" cellpadding="0" border="0" align="center" width="955">
			<tbody>
				<tr>
					<td>
					<table cellspacing="0" cellpadding="0" border="0" bgcolor="#FFFFFF" background="images/bg.png" align="center" width="955" dir="rtl">

						<tbody>
							<tr>
								<td bgcolor="#deecf8" align="center" height="1"></td>
							</tr>
							<tr>
								<td align="center" height="41">&nbsp; &nbsp; <a  href="http://ce.sharif.edu/~moinfar/">امیرعلی معین&zwnj;فر</a>&nbsp;|&nbsp; <a  href="http://ce.sharif.edu/~katebi/">محسن کاتبی</a> &nbsp;|&nbsp; <a  href="http://sadrnezhaad.ir/smm/">سیدمحمدمسعود صدرنژاد</a> &nbsp;|&nbsp; <a  href="http://ce.sharif.edu/~akhavan/">مهران اخوان</a>&nbsp;&nbsp; </td>
							</tr>
							<tr>
								<td align="center" height="33"><a href="."> &nbsp; كليه حقوق اين سايت براي 54.171.10.149 محفوظ مي‌باشد.
								<br>
								استفاده از مطالب در دیگر سایت‌ها و رسانه‌های الکترونیک تنها با ذکر منبع و درج لینک به همان مطلب مجاز است.</a></td>
							</tr>
							<tr>
								<td align="center" valign="middle" height="32" dir="ltr">دانشگاه صنعتی شریف - دانشگاه مهندسی کامپیوتر</td>
							</tr>
						</tbody>
					</table></td>
				</tr>
			</tbody>
		</table>

	</body>
</html>


